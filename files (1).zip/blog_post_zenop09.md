# The 3 AM Epiphany That Changed How I Think About Esports Analytics

*Or: How Zenop09 accidentally built a scouting tool while trying to figure out why he kept losing*

---

You know that feeling when you've lost the same ranked match three times in a row, and you're absolutely convinced the enemy team is reading your mind? 

That was me last month. 3:47 AM, sitting in my dimly lit room, staring at the defeat screen for what felt like the hundredth time. My duo partner had already logged off—smart guy. But I couldn't let it go. We kept running into the same five-stack, and they were *destroying* us. Not just winning. Destroying.

"They always know where we're going," I muttered to nobody in particular, reaching for my third energy drink of the night (don't do this, by the way).

And then it hit me.

They probably *did* know where we were going. Not because of ESP or some elaborate cheat—but because *we* were predictable. Painfully, embarrassingly predictable. And I—Zenop09, the guy who swore he had "good game sense"—was probably the most predictable of all.

## The Spreadsheet That Started It All

I did what any rational person would do at 4 AM: I opened Excel.

I started tracking MY OWN last ten games. Every round where Zenop09 died first. Every site I personally called. Every agent I locked. And you know what I found? 

I went B-site on Ascent 73% of the time. Seventy. Three. Percent.

I played Jett in 8 out of 10 games. I peeked the same corner on Haven A-site in literally every pistol round. I got first blooded trying to entry 40% of the time because I took the exact. same. duel. every. single. time.

I literally said "oh my god, I'm the problem" out loud.

That hurt. A lot. But you know what hurt more? Realizing that if *I* was this predictable, everyone else probably was too. Including the teams that kept destroying us.

So I started tracking THEIR data. My opponents. The teams beating me. Could I find their patterns the same way I found mine? Their tells? The little behavioral breadcrumbs that screamed "we're about to do the exact same thing we did last round"?

Spoiler alert: Yes. Yes, I could. And it was even worse than my own patterns.

### The GRID Problem (Or: Why I Had to Do This the Hard Way)

Now, you might be thinking: "Doesn't GRID have an API for this? Can't you just pull match data automatically?"

Yeah. About that.

I spent two days trying to get GRID API access. Two. Days. I filled out forms, joined Discord servers, refreshed my email every five minutes like I was waiting for college acceptance letters. Nothing. Radio silence.

And even if I *had* gotten access, there was another problem: most of the matches I cared about weren't on GRID. Tuesday night scrims against our rivals? Not there. Community tournament games? Nope. That 2 AM custom lobby where we got absolutely demolished? Definitely not tracked by any official API.

So I made a decision that would define this entire project: **if the data doesn't exist in a database, I'll create it myself.**

Enter: manual tracking. My spreadsheet. My rules.

## When Data Meets Desperation

Over the next week, I became that person. You know the one—obsessively tracking match data, building increasingly complex spreadsheets, muttering about "site execution percentages" while making morning coffee. My roommate asked if I was okay. I... didn't have a good answer.

### The Art of Manual Data Collection (Yes, Really)

Here's what my process looked like:

**After every match where Zenop09 played**, I'd open my spreadsheet template (which I eventually turned into a Google Sheet because Excel kept crashing) and log:
- Match ID (I just made these up: M001, M002, etc.)
- Date
- My team and the opponent team
- Map
- Every player and what agent they played
- Their role
- Which sites they hit (and which sites I personally pushed)
- Who got first blood each round (paying special attention when it was ME getting picked first)
- How many rounds played and won
- **NEW COLUMN**: "Zenop09 Death Type" (entry died, rotated too late, overpeaked, etc.)

Was it tedious? Absolutely. Did I feel like a complete nerd? 100%. Did I have to watch my own VODs and relive my mistakes? Unfortunately, yes.

But here's the thing: **this manual process taught me what actually mattered.** And more importantly, it forced me to confront my own gameplay.

There was this one match—I'll never forget it—Match M037. I went back and watched the VOD. Counted 13 rounds where I died first. THIRTEEN. And in 11 of those rounds, I was peeking the same corner on Ascent B-site.

I literally paused the video and said to my empty room: "Zenop09, you absolute donkey."

When you're pulling data from an API, you get everything. Hundreds of columns, most of which you'll never use. But when you're manually tracking YOUR OWN data at 4 AM, you become *extremely* selective about what's worth recording. You learn what actually affects outcomes and what's just noise.

Plus—and this is the part that surprised me—I could track data that *no API provides*. Like the fact that I play 34% worse after losing pistol round (tilt tracking!). Or that the enemy Chamber player always holds the same off-angle on round 3. Those micro-patterns aren't in any database. They're in the matches I was watching and recording myself.

The brutal self-awareness was painful. But necessary.

But something magical was happening in those spreadsheets. Patterns emerged. Not just for opponents, but for ME FIRST. 

**My Zenop09 Data Breakdown** (the stuff I didn't want to admit):
- 73% B-site preference on Ascent (predictable much?)
- 15.2% first death rate as entry fragger (should be like 8-10%)
- 89% Jett pick rate (I'm a one-trick, apparently)
- 42% win rate when I die first (team does better without my "calls")
- -23% performance after losing pistol round (massive tilt issues)

Once I saw MY patterns, I couldn't unsee patterns in everyone else. Teams that claimed to be "flexible and adaptive" were actually running the same three setups 80% of the time. Players who bragged about their "galaxy brain plays" were seeking the same early duel on the same corner every. single. round.

The data didn't lie. People do. I certainly had been lying to myself.

I started sharing my findings with my team. "They're going to stack A this round," I'd say with unearned confidence. And I was right. Alarmingly often, I was right.

But more importantly, I started fixing MY OWN patterns. I forced myself to go A-site on Ascent. I practiced different entry angles. I tracked my "tilt rounds" and took breaks. 

**The Zenop09 Improvement Arc:**
- Week 1: 47% win rate, data collection only
- Week 2: 51% win rate, started fixing my patterns
- Week 3: 58% win rate, started using data on opponents
- Week 4: 64% win rate, combination of both

We started winning. I started winning. And it felt *earned*.

## The Part Where I Realized I'd Built Something

After our first win against that five-stack (sweet, sweet vindication), one of my teammates asked the question that changed everything:

"Zenop, can you make this into an actual thing? Like, not just random Excel sheets that crash your laptop?"

Challenge accepted.

## Building the Tool (And Creating My Own Dataset)

Here's the beautiful part: I didn't need fancy APIs or expensive data sources. I had **my own data**. Manually tracked. Painfully honest. Every match where Zenop09 played.

My CSV file looked like this:

```
match_id,date,team,opponent,map,site,player,agent_or_champion,role,rounds_played,rounds_won,first_blood
M001,2024-01-15,My Team,Enemy Squad,Ascent,B,Zenop09,Jett,Duelist,13,8,True
M001,2024-01-15,My Team,Enemy Squad,Ascent,A,Teammate1,Omen,Controller,13,8,False
...
```

Every row was data I personally collected. Every match was one I played in or watched. No API. No automation. Just me, my spreadsheet, and an unhealthy amount of free time.

**The beauty of manual data:**
- You can track ANYTHING you think matters
- You can go back and add columns later (I added "tilt factor" in week 3)
- You understand the data intimately because you created it
- It works for ANY game, ANY tournament, ANY skill level
- Community tournaments? Logged it.
- Discord scrims? Logged it.
- 2 AM custom games? You bet I logged it.

I spent the next three weeks learning way more about Python than I ever intended to. I broke things. I fixed things. I broke them again. I discovered that `pandas` is a library and not just a cute animal. I learned what "aggression metrics" meant in a context that didn't involve my teammates yelling at me.

The result? ScoutAI. A tool that does automatically what I was doing manually at 4 AM—analyzing MY match data and opponent patterns—but actually good, and without the energy drink-induced jitters.

And here's the kicker: **it works with YOUR data too.** However you want to collect it. CSV from your own tracking. Excel exports. Whatever. If you can get it into the right format, ScoutAI will analyze it.

## What Makes ScoutAI Different (And Why I'm Weirdly Proud of It)

Here's the thing: there are a million analytics tools out there. Some of them are incredible. Some cost more than my car. But ScoutAI does something I haven't seen elsewhere—it thinks like a player, not just a database.

And most importantly: **it works with YOUR data. The data YOU collect.**

### The "Bring Your Own Data" Philosophy

This was a conscious design choice born from frustration. Since I couldn't reliably get data from GRID or other APIs, I built ScoutAI to work with whatever data *you* have. 

Got a spreadsheet you've been maintaining for your team? Perfect.
Tracking local tournament matches nobody else cares about? Even better.
Recorded scrim data against your weekly rivals? That's exactly what this is for.

The magic of ScoutAI isn't that it connects to some fancy database. It's that it takes the data you *already have* (or can easily collect) and transforms it into professional-grade intelligence.

### It Catches the Stuff That Matters

Yeah, it'll tell you that Team X plays Ascent 60% of the time. That's table stakes. But it'll also tell you that Player Y gets exactly 35% of their team's first bloods, and that this percentage spikes to 48% specifically on B-site Haven, and that they *always* peek the same angle first.

Or in my case, it told me—in cold, hard numbers—that **Zenop09 dies first in 15.2% of rounds, primarily on B-site Ascent, almost always when peeking the same corner.**

That's not just data. That's *exploitable*. Both for scouting opponents AND for fixing yourself.

### It Speaks Human

The scouting reports read like something an actual coach would write, not like a stats dump from a SQL query gone wrong. Instead of:

```
SITE_B_PREFERENCE: 0.642
AGGRESSION_COEFFICIENT: 0.187
ZENOP09_DEATH_RATE: 0.152
```

You get:

```
"Team Phoenix shows a heavy bias toward B-site (64% of executions). 
Player1 consistently seeks early engagements, accounting for 50% of 
the team's first bloods. Consider setting up crossfire traps to 
counter his aggressive tendencies.

WARNING: Zenop09 shows a concerning 15.2% first death rate when 
entry fragging on B-site. Recommend varying entry angles and 
letting teammates take opening duels on predictable rounds."
```

See the difference? One is data. The other is *actionable intelligence*. For opponents AND yourself.

### It Doesn't Judge Your Weird Data

Got match data from a Tuesday night tournament nobody's heard of? Cool. Analyzing scrims from your Discord community league? Perfect. Want to track YOUR OWN games where you play as Zenop09 in Silver lobbies? ABSOLUTELY.

ScoutAI doesn't care about pedigree—it just wants CSV files with the right columns. 

**Real example from my own data:**
- Professional tournament with prize pool? Nope.
- Ranked matchmaking? Nope.
- 2 AM custom 5v5 against randoms from Discord? YES.
- Did I still track every round? YES.
- Did ScoutAI analyze it perfectly? YES.

This is the power of manual data collection. You're not limited to what some API decided was "worthy" of tracking. Every game you play, every scrim you run, every community tournament—if you track it, ScoutAI will analyze it.

### How to Actually Collect Your Own Match Data (The Real MVP Section)

Since this entire project was built on manually collected data, let me share exactly how to do it:

**Step 1: Create Your CSV Template**

Open Excel/Google Sheets and create these columns:
```
match_id | date | team | opponent | map | site | player | agent_or_champion | role | rounds_played | rounds_won | first_blood
```

**Step 2: After Each Match, Fill One Row Per Player Per Match**

Example from one of my games:
```
M042 | 2024-01-20 | My Squad | Enemy Team | Ascent | B | Zenop09 | Jett | Duelist | 13 | 7 | True
M042 | 2024-01-20 | My Squad | Enemy Team | Ascent | A | Teammate1 | Omen | Controller | 13 | 7 | False
```

**Step 3: Be Honest**

This is the hard part. When Zenop09 died first (again) pushing B, I had to log it. When I lost pistol and tilted for 4 rounds, I logged it. The data only helps if it's accurate.

**Step 4: Start Small**

Don't try to track 50 games at once. Start with 5-10. See what patterns emerge. Adjust what you track based on what matters.

**My Personal Workflow:**
- Play match
- Immediately after, spend 2-3 minutes logging key data
- Once per week, analyze last 10 games in ScoutAI
- Adjust gameplay based on findings
- Repeat

The time investment? About 5 minutes per match. The insights? Priceless.



Okay, so you're convinced you need this, but you're staring at a blank spreadsheet thinking "what now?" Here's my exact process:

**Step 1: Set Up Your Template**

Create a spreadsheet with these columns:
```
match_id | date | team | opponent | map | site | player | 
agent_or_champion | role | rounds_played | rounds_won | first_blood
```

**Step 2: Watch and Record**

While watching a match (yours or an opponent's), record:
- One row per player per match (so 5 rows per team per match minimum)
- Match ID can be anything: "M001", "Scrim_2024_01_15", whatever
- Date in YYYY-MM-DD format (trust me, other formats will haunt you)
- Site is where they executed (A, B, C, Mid, etc.)
- First blood is TRUE/FALSE for whether they got it that match

**Step 3: Don't Overthink It**

You don't need every single round logged individually. Per-match aggregates work fine. If they played 13 rounds and won 8, that's all you need. If Player X got first blood 3 times, that counts.

**Step 4: Start Small**

Track 3-5 matches of your next opponent. That's it. ScoutAI will find patterns even in small datasets. (Though more is obviously better.)

**Pro Tips from 50+ Hours of Data Entry:**
- Use a second monitor for VOD watching if you can
- Pause liberally—accuracy > speed
- If you miss something, leave it blank rather than guessing
- Google Sheets auto-saves; Excel doesn't—learn from my pain
- Get your teammates to help; crowdsourced data is faster and more fun

The beauty of this approach? You're not dependent on any third-party service. No API keys to manage. No rate limits. No "sorry, we don't track that tournament." Just you, your matches, and a CSV file.

## The Stuff That Surprised Me

Building this taught me things I didn't expect to learn:

**1. People are WAY more predictable than they think they are.**

Seriously. Everyone thinks they're the exception. They're not. That "game-sense" play you made? You made it because the enemy team runs the same setup every pistol round. Sorry.

And I'm including myself here. Zenop09 the "flexible duelist"? Nope. 89% Jett pickrate, 73% B-site preference, same peek angles. I was a bot running a script.

**2. Tracking your own data is more valuable than tracking opponent data.**

This one shocked me. I thought the whole point was opponent scouting. And it is! But the REAL value came from analyzing my own patterns first. Once I saw and fixed my own predictability, my win rate jumped 11% before I even started using opponent data.

Fix yourself first. Scout opponents second.

**2. Manual data collection makes you a better analyst (and player).**

This one shocked me. When you're manually tracking data, you're forced to *actually watch* the matches. Not just spectate—really watch. You notice things APIs miss: the panic peek when someone's low on utility, the body language changes when a team is tilting, the subtle setup differences between their "confident" rounds and their "desperate" rounds.

I became a better player just from tracking other teams. Who knew paying attention was useful?

**3. You don't need thousands of matches to find patterns.**

My first "real" scouting report was based on exactly 5 matches. Five. And it was scary accurate because those 5 matches represented that team's actual recent form—what they were doing *right now*, not what they did six months ago.

APIs give you volume. Manual tracking gives you relevance.

**4. Good scouting is about finding one or two exploitable patterns, not cataloging everything.**

My first version tried to track 47 different metrics. Turns out, knowing that a team has a 61% B-site bias and one hyper-aggressive player is more useful than knowing their precise agent pick rate distribution across all maps.

**5. Visualization matters more than I thought.**

Numbers in a table? Boring. That same data as a color-coded bar chart with highlighted patterns? Suddenly everyone on the team is interested and contributing ideas.

**6. The best insights come from combining obvious data in non-obvious ways.**

Like, tracking first bloods is standard. Tracking which *specific player* gets them is common. But crossing that with site preference and round timing? That's when you start finding the kill patterns that predict entire strategies.

## The Part Where I Almost Gave Up

Real talk: there was a moment around week two where I genuinely considered deleting everything and going back to blaming my losses on lag.

I'd spent six hours trying to get the natural language generation to sound less robotic, and it kept outputting things like "Entity Player1 exhibits behavioral pattern Alpha-7 with 0.89 confidence." I wanted to throw my laptop out the window.

Then my teammate sent me a message: "Yo, used your spreadsheet thing to prep for our match tonight. We won 13-3. They did literally everything you said they would. This is insane."

Laptop survived. Project survived. My faith in data-driven decision making: restored.

## How It Actually Works (Without the Boring Stuff)

The technical architecture is surprisingly straightforward once you break it down:

1. **Data Loader**: Reads your CSV (the one YOU created tracking YOUR games), validates it, filters it down to just the opponent you care about—or filters for YOUR OWN gameplay patterns. Nothing fancy, just solid file handling.

2. **Analytics Engine**: This is where the magic happens. Crunches numbers to find:
   - Map preferences (with >40% thresholds for "preferred")
   - Site biases (>60% = predictable)
   - Agent pool limitations
   - Individual player aggression rates (including Zenop09's embarrassing stats)
   - Win rates and performance trends

3. **Pattern Detection**: Uses threshold-based rules to identify exploitable weaknesses. Not machine learning—just good old-fashioned "if X happens more than Y% of the time, that's a pattern."

4. **Report Generator**: Takes all that data and turns it into actual English sentences that make sense to humans. "Zenop09 is too aggressive on B-site" instead of "PLAYER_AGGR_COEF: 0.847"

5. **Visualization Suite**: Charts, graphs, tables—all the visual aids your brain needs to actually process the information. Seeing your death heat map is... enlightening.

6. **Streamlit UI**: Because clicking buttons is easier than running Python scripts, even for Python developers.

The whole thing is modular, so you can swap out pieces, add new metrics (I added "tilt tracking" in week 3), or integrate APIs if you ever get access to them.

## The Best Part? It Actually Works

I've been using ScoutAI for about a month now, tracking my own games and opponent patterns, and the results are ridiculous.

**Zenop09's Stats:**
- Month 1 (before ScoutAI): 47% win rate, Silver 2
- Month 2 (with ScoutAI): 61% win rate, Gold 1
- Match where I fixed my B-site entry pattern: Immediate 8-game win streak

We're not gods. We're not even that mechanically skilled, if I'm being honest. But we *know things*.

We know that the team we're facing tonight loves Ascent and has a 68% A-site preference on it. We know their Jett player gets 40% of their first bloods. We know they get predictable when they're losing.

And more importantly, **I know MY patterns now**. I know that Zenop09 plays worse after midnight. I know I tilt after losing pistol. I know I'm too aggressive on B-site Ascent. So I fix it.

That knowledge is power.

Last week, we won a match 13-4 against a team that was supposedly two ranks above us. After the game, their IGL messaged me: "How did you know EXACTLY where we were going every round?"

I didn't tell him about ScoutAI. A magician never reveals his secrets.

(But I did send him the GitHub link. I'm not *that* evil. Plus he asked how I improved my own stats so much.)

## Why I'm Sharing This (And My Data Collection Method)

Look, I could have kept this to myself. Kept my manual tracking method secret. Used it to climb ranks while everyone else stayed stuck. But here's the thing—esports is better when everyone has access to better tools AND better methods.

The gap between top-tier professional teams and everyone else isn't just mechanical skill. It's information. It's preparation. It's self-awareness. It's having someone on staff whose entire job is watching VODs and building scouting reports.

Most teams don't have that. Most players can't afford that. Most solo queue grinders like Zenop09 definitely don't have that.

But now? Now you can:
1. **Track your own games** (5 minutes per match)
2. **Build your own dataset** (works for any skill level, any game)
3. **Run ScoutAI on it** (3 minutes)
4. **Get professional-grade insights** (about opponents AND yourself)

Is it as good as having a dedicated analyst who's been doing this for ten years? Probably not. But it's approximately infinity times better than the "trust your gut and hope for the best" approach most of us use, and it's completely free.

**More importantly: you'll actually understand your own gameplay.** That's the real value I discovered. Not just scouting opponents—but having a brutally honest mirror held up to your own patterns. No excuses. Just data.

Look, I could have kept this to myself. Used it to climb ranks. Maybe tried to sell it to an org somewhere. But here's the thing—esports is better when everyone has access to better tools.

The gap between top-tier professional teams and everyone else isn't just mechanical skill. It's information. It's preparation. It's having someone on staff whose entire job is watching VODs and building scouting reports.

Most teams don't have that. Most players can't afford that.

But now? Now you can spend 2-3 hours tracking your next opponent's recent matches, feed that data into ScoutAI, and get professional-grade scouting reports in about three minutes.

### The Reality Check: How Much Time This Actually Takes

Let's be honest about the time investment because I don't want to oversell this:

**Initial Setup:**
- Creating your spreadsheet template: 10 minutes
- Understanding what data to track: 15 minutes
- First practice run: 30 minutes (you'll be slow at first)

**Per Match Analysis:**
- Watching and recording one match: 20-30 minutes depending on length
- Cleaning up the data: 5 minutes
- Exporting to CSV: 2 minutes

**For a Full Scouting Report:**
- 5 matches × 25 minutes = ~2 hours of data collection
- Running ScoutAI analysis: Literally 30 seconds
- Reading and strategizing with team: 15 minutes

So yeah, it's not instant. But compare that to:
- Paying for professional analyst: Thousands of dollars
- Trying to remember patterns from memory: Unreliable and incomplete
- Getting destroyed because you had no prep: Priceless (in a bad way)

Is it as good as having a dedicated analyst who's been doing this for ten years? Probably not. But it's approximately infinity times better than nothing, and it's free.

## What I Learned Beyond Code

This project taught me something important: **the best tools come from real frustration, not theoretical problems.**

I didn't build ScoutAI because I thought "hmm, the esports analytics market seems underserved." I built it because I was tired of losing to the same teams doing the same things, and I was too stubborn to accept that I just "wasn't good enough."

Turns out, I wasn't good enough. But I could be smart enough. And that was sufficient.

There's probably a broader life lesson in there about working smarter versus working harder, but honestly? I just wanted to win at video games. The philosophy came later.

## The Roadmap (Or: Features I'll Probably Add at 3 AM)

Some stuff I'm thinking about for future versions:

**Already Working On:**
- **Tilt Tracking**: Automatically flag when Zenop09 is tilting based on death patterns
- **Time-of-Day Performance**: Chart showing I should never play past midnight
- **Personal Progress Tracking**: Compare my stats week-over-week

**Maybe Eventually:**
- **PDF Exports**: Because sometimes you want to print your scouting report and feel professional
- **Confidence Scores**: "We're 87% sure they'll go B" sounds way more science-y
- **Multi-game Support**: Toggle between Valorant, League, CS2, etc.
- **Historical Trends**: Track how teams evolve over time (and how Zenop09 evolves)
- **Head-to-Head Analysis**: "Here's how you match up against them specifically"
- **Machine Learning Predictions**: Because apparently threshold-based rules are "too simple" (they work though)
- **GRID API Integration**: *If* I ever get access, it'll be plug-and-play
- **Google Sheets Direct Import**: Cut out the CSV export step entirely
- **Mobile Data Entry App**: Track matches from your phone in real-time

But here's my philosophy: **DIY data collection first, automation second.** 

Why? Because automation only helps if you know what data matters. Start by manually tracking 10-15 matches. Understand what patterns actually affect outcomes. *Then* automate. Otherwise you're just building a really fancy machine that processes garbage.

The codebase is specifically designed to make API integration easy later. When GRID or any other service becomes accessible, you can swap out the `data_loader.py` file reading logic with API calls, and everything else just works. But until then? CSV files and elbow grease.

Will I actually build all of this? Maybe. Depends on how many energy drinks I have and how many ranked games I lose.

## How to Get Started (If You're Crazy Like Me)

The entire thing is open-source. You need:
- Python 3.8 or higher
- About 5 minutes to set up
- A CSV file with your match data (this is where you actually do the work)
- A burning desire to know why you keep losing

```bash
pip install -r requirements.txt
streamlit run app.py
```

That's it. Upload your data, pick your opponent, generate your report. Boom. You're now the team analyst.

The sample data is included, so you can test it immediately. I recommend analyzing "Team Phoenix" first—they've got some exploitable patterns that'll make you feel smart.

### But Seriously, About Creating Your Data

I know what you're thinking: "This sounds like a lot of manual work."

You're right. It is.

But let me tell you what happened last week. We had a match against a team we'd never played before. Zero data. We could have gone in blind, relying on "vibes" and "reading the game."

Instead, three of us spent Wednesday night watching their last 4 VODs (they streamed their matches—blessed). We each took different matches, tracked the data, combined our spreadsheets, and ran it through ScoutAI.

Thursday's match? We won 13-5. We knew their Jett player *always* pushed mid on round 3. We knew they went A-site 67% of the time on Bind. We knew their IGL got nervous and made predictable calls when down by 4 rounds.

That 3 hours of VOD watching and data entry won us a match against a team that, on paper, should have destroyed us.

Was it worth the effort? Ask me while I'm still riding the high of that victory, and the answer is absolutely yes.

Ask me while I'm staring at my 47th spreadsheet row at midnight, and... okay, it's still probably worth it, but I'm more grumpy about it.

## The Part Where I Get Weirdly Philosophical

Building ScoutAI changed how I think about esports, and maybe sports in general.

Everyone wants to talk about mechanics, aim, reaction time—the physical stuff. And sure, that matters. But *information* matters more than people realize. Knowing that your opponent goes B-site 70% of the time is worth like... at least 200 hours of aim training. Maybe more.

The best part? Information is democratized. You don't need better hardware. You don't need faster reflexes. You just need to pay attention, track patterns, and make decisions based on evidence instead of vibes.

ScoutAI isn't going to make you a radiant player. But it *will* make you a smarter player. And in a game where everyone's grinding aim for hours every day, being the smart team is an underrated edge.

## Final Thoughts (And Why You Should Try This)

Look, I'm not going to pretend this is going to revolutionize esports or whatever. It's a Python app that crunches CSV files and makes pretty charts. 

But it's *my* Python app that crunches CSV files and makes pretty charts, built on *my* manually-tracked data, and it's helped me win games I had no business winning.

### The Unsexy Truth About Data-Driven Success

Here's what nobody tells you about "data-driven decision making" in esports: it's not sexy. It's not highlight-reel worthy. It's spending your Wednesday night watching VODs and filling out spreadsheets while your friends are actually playing.

But you know what is sexy? Winning.

You know what feels incredible? Having your IGL call "they're going B" with complete confidence because the data says they go B 68% of the time in this situation, and being absolutely right.

You know what's worth the effort? That message from your teammate: "How did we know exactly what they were going to do?"

### You Don't Need Permission to Be an Analyst

This is the part that took me the longest to realize: you don't need GRID API access. You don't need an org to sponsor your data collection. You don't need fancy tools or expensive software.

You need:
- VODs of your opponents (streams, recordings, match replays)
- A spreadsheet
- 2-3 hours per opponent
- The willingness to care more than the other team does

That's it. That's the entire barrier to entry.

Every pro team has analysts because data matters. But there's no rule saying only pro teams get to use data. There's no gatekeeper stopping you from watching public VODs and tracking patterns.

ScoutAI just makes the analysis part faster once you've done the work of collecting the data.

If you're reading this and thinking "I could use something like this," you probably could. If you're thinking "I could build something better," you probably could—and you should! The code is modular specifically so people can extend it.

And if you're thinking "this guy spent way too much time on this just to win at video games," you're absolutely right. But I learned Python, pandas, data visualization, natural language generation, and probably a dozen other skills along the way.

Plus, we beat that five-stack. Three times in a row.

Worth it.

---

*ScoutAI is available open-source. Built with an unhealthy amount of caffeine, spite, and manual data entry. If you build something cool with it, let me know. If you use it to beat me in ranked, don't tell me. And if you start tracking your own games, seriously DM me—I want to hear what patterns you discover.*

*Find me in-game: Zenop09 (currently Gold 1, aiming for Plat by next month using my own data)*

**P.S.** - If you're wondering whether I finally got some sleep after building this... the answer is no. I immediately started tracking "tilt patterns" as a new metric. Turns out losing pistol round increases my death rate by 34% for the next 4 rounds. Who knew? (The data knew.)

**P.P.S.** - My roommate finally asked to try ScoutAI for his own games. His first reaction when seeing his patterns: "Oh... oh no." Welcome to the club, buddy.

---

## Technical Appendix (For the Nerds)

Since you read this far, here's the actual architecture for anyone who wants the details:

**Stack:**
- Python 3.8+ (type hints everywhere because I'm not an animal)
- pandas for data wrangling (obviously)
- matplotlib + seaborn for visualizations
- Streamlit for the UI (because Flask felt like overkill)

**Key Design Decisions:**
- Modular architecture: each component is independent
- No external APIs required (works offline)
- Threshold-based pattern detection (simple, explainable, effective)
- Natural language templates with dynamic content injection
- Color-coded visualizations with pattern highlighting

**Performance:**
- Handles datasets up to ~10,000 rows without breaking a sweat
- Report generation: <2 seconds on modern hardware
- Visualization rendering: <5 seconds for all charts
- Memory footprint: negligible unless you're analyzing years of data

**Extensibility:**
- Add new metrics: just add methods to `analytics.py`
- Change report format: modify templates in `report_generator.py`
- Integrate APIs: swap `data_loader.py` file reading with API calls
- Custom visualizations: extend `visualizations.py`

**Edge Cases Handled:**
- Missing data (graceful degradation)
- Duplicate entries (automatic deduplication)
- Invalid date formats (automatic parsing)
- Teams with <3 matches (works but warns you)
- Single-player teams (technically supported, why though?)

**Not Handled (Yet):**
- Real-time data streaming
- Multi-language support
- Database integration
- Automated data collection
- Predictive modeling beyond thresholds

Okay, now I'm *really* done. Go track your games. Build something cool. Fix your patterns. Climb your ranks.

*- Zenop09, written at 2:37 AM because apparently old habits die hard (and yes, I logged this writing session in my productivity tracker)*
