# Your Personal Match Tracking Guide
## Start Building Your ScoutAI Dataset Today

*By Zenop09 - The guy who manually tracked 100+ games and lived to tell the tale*

---

So you read the blog post and thought "I want to do this too." Great! Here's exactly how to start tracking your own match data, step by step.

## Why This Works (Even If You're Not "Good")

Before we dive in, let me be clear: **this works at ANY skill level.** 

I started tracking when I was hardstuck Silver 2. The data was just as valuable. Actually, it was MORE valuable because I had more room to improve.

Your rank doesn't matter. Your mechanics don't matter. What matters is that you're willing to be honest with yourself about your patterns.

---

## The 5-Minute Per Match Method

### What You Need:
- Google Sheets (or Excel, but Sheets is better for this)
- 5 minutes after each match
- Honesty (this is the hard part)

### Step 1: Create Your Tracking Sheet

Open Google Sheets and create these columns:

```
match_id | date | team | opponent | map | site | player | agent_or_champion | role | rounds_played | rounds_won | first_blood
```

**What each column means:**
- `match_id`: Just make it up (M001, M002, etc.)
- `date`: When you played (YYYY-MM-DD format)
- `team`: Your team name (I use "Zenop Squad" for mine)
- `opponent`: Enemy team name (make one up if it's random matchmaking)
- `map`: Which map
- `site`: Which site you pushed (A, B, C, Mid, etc.)
- `player`: Player name (YOU or teammates)
- `agent_or_champion`: What they played
- `role`: Duelist, Controller, Sentinel, Initiator (or Top, Jung, Mid, ADC, Sup for LoL)
- `rounds_played`: How many rounds total
- `rounds_won`: How many you won
- `first_blood`: TRUE if this player got first blood, FALSE if not

### Step 2: Log ONE Match (Practice Round)

Let's say you just played Ascent. Your team is "My Squad", enemy was "Random Team". 

You (Zenop09) played Jett as Duelist. Match went 13-7, you won. You got first blood in 2 rounds out of 13. You pushed B-site in 9 rounds, A-site in 4 rounds.

**How to log it:**

Create TWO rows minimum per match - one for each site you played:

```
M001,2024-02-03,My Squad,Random Team,Ascent,B,Zenop09,Jett,Duelist,9,6,True
M001,2024-02-03,My Squad,Random Team,Ascent,A,Zenop09,Jett,Duelist,4,1,False
```

Wait, why two rows for one player?

Because we're tracking which SITE you played each round. If you want detailed data, you'd create one row per round. But that's overkill for starting out. Site-level aggregation is enough.

**Pro tip:** You can add rows for teammates too if you want to track your whole team's patterns. But start with just YOU. 

### Step 3: What to Track During the Match

You don't need to pause between rounds. Just play normally. After the match ends, recall:

**Quick Mental Notes (30 seconds while match is ending):**
- Which sites did I push most?
- How many times did I die first? (Check scoreboard)
- Did we win or lose?
- Any notable patterns? (write in a notes app if needed)

**Then immediately log it in the sheet** (5 minutes):
- Fill out your rows
- Don't overthink it
- Move on to next game

### Step 4: Repeat for 5-10 Matches

You need at least 5 matches to see patterns. 10 is better. 20 is great.

Don't try to track 50 matches at once. You'll burn out. Just commit to tracking your next 10 games this week.

---

## Common Questions (FAQ)

**Q: Do I track EVERY round as a separate row?**

A: Not when starting. Just aggregate by site. Example: If you played 13 rounds and 9 were B-site, make one row for B (9 rounds) and one for A (4 rounds).

**Q: What if I don't remember exactly how many rounds per site?**

A: Estimate. Close enough is good enough. You're looking for patterns (60% B-site vs 40% A-site), not exact numbers.

**Q: Do I track casual matches or only ranked?**

A: EVERYTHING. Unrated, ranked, custom games, scrims. All of it. Patterns exist everywhere.

**Q: What if my teammates ask what I'm doing?**

A: Tell them. Share your findings. They'll either think you're crazy or ask you to analyze their games too.

**Q: How do I track "first blood" accurately?**

A: Look at the kill feed at the start of each round. Who got the first kill? Was it you? TRUE. Was it someone else? FALSE. If nobody got first blood (timer ran out), mark FALSE.

**Q: I don't always remember which site we pushed.**

A: Open the map replay if your game has it. Or check VOD if you record. Or just estimate based on memory. Again, close enough works.

**Q: Can I add extra columns for things like "tilt factor" or "time of day"?**

A: YES! That's the beauty of tracking your own data. Add whatever you think matters. I added:
- `time_played` (hour of day)
- `tilted` (boolean - was I tilted?)
- `entry_success` (did I win my entry duel?)

---

## The Brutal Truth Section

Here's what's going to happen when you start tracking:

### Week 1: Denial
"I'm pretty flexible, I play all sites equally."

*Checks data: 78% B-site*

"...oh."

### Week 2: Anger
"Why do I keep dying first?!"

*Checks data: 23% first death rate, primarily from peeking same corner*

"COME ON."

### Week 3: Depression
"I'm just bad at this game."

*Checks data: 34% lower win rate after losing pistol round*

"I'm tilted AND predictable."

### Week 4: Acceptance
"Okay, I have patterns. Time to fix them."

*Adjusts gameplay, checks data after 5 more matches*

"Wait... my win rate went up 8%?"

### Week 5: Evangelism
"EVERYONE SHOULD BE TRACKING THEIR DATA."

*Sends this guide to entire Discord server*

---

## Real Examples from My Data

Here are actual patterns I found in my first month:

### Pattern 1: The Midnight Curse
**Discovery:** My win rate dropped 17% after 11 PM

**The Data:**
- Games before 11 PM: 54% win rate
- Games after 11 PM: 37% win rate

**The Fix:** Stop playing ranked after 11 PM. No exceptions. Even if I'm "feeling it."

### Pattern 2: The B-Site Addiction
**Discovery:** I went B-site on Ascent 82% of the time

**The Data:**
- 41 rounds on B-site
- 9 rounds on A-site
- Enemy started stacking B by round 5

**The Fix:** Forced myself to call A-site. Felt weird. Worked immediately.

### Pattern 3: The Pistol Tilt
**Discovery:** After losing pistol round, my next 4 rounds were 31% worse

**The Data:**
- Win pistol → next 4 rounds: 58% win rate
- Lose pistol → next 4 rounds: 27% win rate

**The Fix:** After losing pistol, take 10 seconds to reset mentally before round 2.

### Pattern 4: The Entry Problem
**Discovery:** I died first in 19% of rounds

**The Data:**
- Entry attempts: 47 rounds
- Entry deaths: 9 rounds (19%)
- Team win rate when I died first: 23%

**The Fix:** Let teammates entry on predictable rounds. My job isn't ALWAYS to go first.

---

## How to Use Your Data with ScoutAI

Once you have 5-10 matches tracked:

1. **Save your Google Sheet as CSV**
   - File → Download → Comma Separated Values (.csv)

2. **Run ScoutAI**
   ```bash
   streamlit run app.py
   ```

3. **Upload YOUR CSV**

4. **Select YOUR team as the "opponent"** (yes, scout yourself first)

5. **Read the brutal truth**

6. **Fix ONE pattern**

7. **Track 5 more matches**

8. **Repeat**

---

## Advanced Tracking (Once You're Hooked)

After you're comfortable with basic tracking, consider adding:

### Time-Based Columns
- `time_of_day`: Hour you played (for performance analysis)
- `day_of_week`: Are you worse on Monday? (I am)
- `session_number`: First game of session vs 5th game

### Performance Columns  
- `kills`: Your kills that match
- `deaths`: Your deaths
- `assists`: Your assists
- `acs` (Average Combat Score): If your game tracks it

### Mental State Columns
- `tilted`: Were you tilted? (honest answers only)
- `warmed_up`: Did you warm up before this match?
- `sleep_hours`: Hours of sleep last night

### Team Columns
- `teammate_1` through `teammate_4`: Who you played with
- `comms_quality`: Good comms? (1-5 scale)
- `team_tilt`: Was team tilted?

**Warning:** Don't track too much at once. Start simple. Add columns as you discover what matters.

---

## The Weekly Review Process

Every Sunday, I spend 30 minutes reviewing my data:

### The Zenop09 Weekly Review Checklist:

**1. Export last week's data from Google Sheets**

**2. Run ScoutAI on it**

**3. Answer these questions:**
- What was my win rate this week vs last week?
- Did I fix the pattern I was working on?
- What new pattern emerged?
- What's ONE thing to focus on next week?

**4. Share findings with team** (if you play with consistent teammates)

**5. Set ONE goal for next week** (Example: "Play A-site 50% of the time")

**6. Track compliance** (Did I actually do it?)

---

## Motivation for When You Want to Quit

Let me be real: This is tedious. You'll want to quit. Here's why you shouldn't:

### You'll Quit When:
- You have a bad loss and don't want to log it
- You're tired and 5 minutes feels like too much
- You think "I already know my patterns"
- Your friends make fun of you for "doing homework"

### You'll Keep Going When:
- You see your first pattern (the "oh no" moment)
- You fix a pattern and see immediate improvement
- Your win rate goes up
- You win a game specifically because you analyzed opponents
- Your teammates start asking for your insights

The second list is way better than the first list. Trust me.

---

## Start Today (Literally Right Now)

1. **Open Google Sheets**
2. **Create the columns** (copy from the guide above)
3. **Play ONE match**
4. **Log it immediately after**
5. **You're now a data-driven player**

That's it. You're in the club. Welcome.

No API access needed. No expensive tools. No guru courses. Just you, a spreadsheet, and the willingness to face uncomfortable truths about your gameplay.

---

## Final Thoughts

I'm not special. I'm not a Radiant player. I'm not a coach or analyst by trade.

I'm just a guy named Zenop09 who got tired of losing and decided to do something about it.

If I can track 100+ matches manually while working full-time, you can track 10.

If I can go from Silver 2 to Gold 1 using this method, you can improve too.

If I can face the brutal truth that I'm predictable, tilted, and overly aggressive... so can you.

The data is waiting. The patterns are there. You just have to look.

Start with one match. See where it takes you.

---

*Questions? Reach out: Zenop09 on your platform of choice*

*Using this guide? Let me know what patterns you discover. Seriously. I want to hear the "oh no" stories.*

**Now close this guide and go play a match. Then log it. That's your homework.**

---

## Appendix: Quick Reference CSV Template

Copy-paste this into your Google Sheet:

```
match_id,date,team,opponent,map,site,player,agent_or_champion,role,rounds_played,rounds_won,first_blood
M001,2024-02-03,My Team,Enemy Team,Ascent,B,YourName,Jett,Duelist,13,8,True
```

Replace:
- `M001` → Your match number
- `2024-02-03` → Today's date  
- `My Team` → Your team name
- `Enemy Team` → Their team name
- `Ascent` → The map
- `B` → The site
- `YourName` → Your IGN
- `Jett` → Agent you played
- `Duelist` → Your role
- `13` → Rounds played
- `8` → Rounds won
- `True` → Got first blood (or False)

Done. You have data. Now track 9 more matches and run ScoutAI.

Good luck, and remember: the first pattern you discover will hurt. That's how you know it's working.

*- Zenop09*
