# ScoutAI - Automated Opponent Scouting

**ScoutAI** is a production-ready Python application that automatically generates comprehensive scouting reports for esports teams using historical match data. Built with modular, extensible code for easy integration with APIs like GRID.

## 🎯 Features

- **Automated Analytics**: Calculate map preferences, site biases, agent usage, and aggression metrics
- **Player Profiling**: Identify individual player tendencies and behavioral patterns
- **Natural Language Reports**: Generate human-readable scouting reports with actionable insights
- **Visual Analytics**: Create professional charts and visualizations
- **Interactive UI**: Streamlit-based web interface for easy interaction
- **Extensible Design**: Modular architecture ready for API integration

## 📋 Requirements

- Python 3.8+
- pandas
- matplotlib
- seaborn
- streamlit

## 🚀 Quick Start

### 1. Installation

```bash
# Install dependencies
pip install -r requirements.txt
```

### 2. Run the Application

```bash
# Launch Streamlit app
streamlit run app.py
```

The app will open in your browser at `http://localhost:8501`

### 3. Using the Sample Data

Upload the included `sample_match_data.csv` file to test the application:
- Select "Team Phoenix" or "Team Dragon" as the opponent
- Choose number of matches (1-5 available in sample)
- Click "Generate Scouting Report"

## 📊 Data Format

Your CSV file must include the following columns:

| Column | Type | Description |
|--------|------|-------------|
| `match_id` | string | Unique match identifier |
| `date` | date | Match date (YYYY-MM-DD) |
| `team` | string | Team name |
| `opponent` | string | Opponent team name |
| `map` | string | Map name |
| `site` | string | Site/lane identifier |
| `player` | string | Player name |
| `agent_or_champion` | string | Character played |
| `role` | string | Player role |
| `rounds_played` | int | Rounds played |
| `rounds_won` | int | Rounds won |
| `first_blood` | bool | First blood achieved (True/False) |

## 🧮 Analytics Computed

### Team-Level Metrics
- **Map Preference**: Percentage usage per map (flags >40%)
- **Site Bias**: Execution preferences (flags >60%)
- **Agent Pool**: Champion/agent usage distribution
- **Aggression Rate**: First blood percentage
- **Win Rate**: Overall round win percentage

### Player-Level Metrics
- **Role Assignment**: Primary role per player
- **Agent Preference**: Most-played characters
- **Aggression Tendency**: Individual first blood rates
- **Performance Stats**: Win rates and round counts

### Pattern Detection
- Identifies predictable strategies (>30% agent usage)
- Flags aggressive players (above team average)
- Detects site execution biases
- Highlights exploitable weaknesses

## 📁 Project Structure

```
scoutai/
├── app.py                  # Streamlit web interface
├── data_loader.py          # CSV ingestion and filtering
├── analytics.py            # Metrics calculation engine
├── report_generator.py     # Natural language report creation
├── visualizations.py       # Chart generation
├── requirements.txt        # Python dependencies
├── sample_match_data.csv   # Test dataset
└── README.md              # This file
```

## 💻 Usage Examples

### Command Line Usage

```python
from data_loader import MatchDataLoader
from analytics import ScoutingAnalytics
from report_generator import ScoutingReportGenerator

# Load data
loader = MatchDataLoader("sample_match_data.csv")
team_data = loader.get_opponent_data("Team Phoenix", num_matches=5)

# Perform analytics
analytics = ScoutingAnalytics(team_data)
map_pref = analytics.calculate_map_preference()
player_stats = analytics.calculate_player_tendencies()

# Generate report
analytics_data = {
    'summary': analytics.get_summary_statistics(),
    'map_preference': map_pref,
    'player_tendencies': player_stats,
    'patterns': analytics.identify_patterns(),
    # ... other metrics
}

report = ScoutingReportGenerator(
    "Team Phoenix",
    analytics_data,
    loader.get_date_range(team_data)
)

print(report.generate_full_report())
```

### Creating Visualizations

```python
from visualizations import ScoutingVisualizer

visualizer = ScoutingVisualizer(analytics_data, "Team Phoenix")

# Generate individual plots
visualizer.plot_map_preference(save_path="map_chart.png")
visualizer.plot_agent_usage(save_path="agent_chart.png")

# Generate all plots at once
plots = visualizer.generate_all_plots(output_dir="./charts")
```

## 🔧 Extending ScoutAI

### Adding New Metrics

Edit `analytics.py` and add new calculation methods:

```python
def calculate_custom_metric(self) -> pd.DataFrame:
    """Your custom metric calculation."""
    # Your logic here
    return result_df
```

### Integrating APIs (e.g., GRID)

Replace file loading in `data_loader.py`:

```python
def _load_from_api(self, api_key: str) -> None:
    """Fetch data from GRID API."""
    response = requests.get(
        "https://api.grid.gg/endpoint",
        headers={"Authorization": f"Bearer {api_key}"}
    )
    self.data = pd.DataFrame(response.json())
```

### Custom Report Templates

Modify `report_generator.py` methods to change report format:

```python
def generate_custom_section(self) -> str:
    """Add your custom report section."""
    return "Your custom content"
```

## 📈 Sample Output

```
======================================================================
SCOUTAI OPPONENT SCOUTING REPORT
======================================================================

Team: Team Phoenix
Analysis Period: 2024-01-15 to 2024-01-28
Matches Analyzed: 5
Total Rounds: 63
Players Tracked: 5

======================================================================

TEAM PLAYSTYLE OVERVIEW
----------------------------------------------------------------------

Team Phoenix displays a highly aggressive playstyle with a 61.9% round 
win rate, indicating strong recent performance.

PREFERRED STRATEGIES
----------------------------------------------------------------------

Map Selection:
  • Strong preference for Ascent (60.0% of matches)

Site/Lane Execution:
  • Heavy bias toward B (64.0% of executions)

Agent/Champion Pool:
  • Jett: 25.0% usage
  • Omen: 20.0% usage
  • Sage: 20.0% usage

KEY PLAYER TENDENCIES
----------------------------------------------------------------------

Player1 (Duelist):
  • Favorite Agent: Jett
  • Rounds Played: 63
  • Win Rate: 61.9%
  • Aggression Rate: 15.87%
  • ⚠️  AGGRESSIVE PLAYER - Seeks early engagements (62.5% of team's first bloods)

...
```

## 🎮 Supported Games

- **Valorant**: Site-based execution analysis
- **League of Legends**: Lane preference tracking
- **Any round/lane-based esport**: Easily adaptable

## 🚀 Future Enhancements

- [ ] PDF export functionality
- [ ] Confidence scores for predictions
- [ ] Game mode toggle (Valorant/LoL/etc.)
- [ ] Real-time API integration
- [ ] Historical trend analysis
- [ ] Head-to-head comparisons
- [ ] Machine learning predictions

## 📝 License

This project is provided as-is for educational and analytical purposes.

## 🤝 Contributing

To extend or modify ScoutAI:
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test with sample data
5. Submit a pull request

## 📧 Support

For questions or issues, please refer to the inline documentation in each module.

---

**Built with ❤️ for the esports analytics community**
