"""
ScoutAI Analytics Module
Computes team metrics, player tendencies, and strategic insights.
"""

import pandas as pd
from typing import Dict, List, Tuple


class ScoutingAnalytics:
    """Perform analytical calculations on match data."""
    
    def __init__(self, match_data: pd.DataFrame):
        """
        Initialize analytics with match data.
        
        Args:
            match_data: Filtered DataFrame for the opponent team
        """
        self.data = match_data
        self.total_matches = match_data['match_id'].nunique()
        self.total_rounds = match_data['rounds_played'].sum()
    
    def calculate_map_preference(self) -> pd.DataFrame:
        """
        Calculate map preference percentages.
        
        Returns:
            DataFrame with map names and their usage percentages
        """
        map_counts = self.data.groupby('map')['match_id'].nunique()
        map_preference = (map_counts / self.total_matches * 100).round(2)
        
        return pd.DataFrame({
            'map': map_preference.index,
            'matches_played': map_counts.values,
            'preference_pct': map_preference.values
        }).sort_values('preference_pct', ascending=False)
    
    def calculate_site_preference(self) -> pd.DataFrame:
        """
        Calculate site/lane execution preference.
        
        Returns:
            DataFrame with site/lane names and their usage percentages
        """
        site_counts = self.data.groupby('site').size()
        total_executions = site_counts.sum()
        site_preference = (site_counts / total_executions * 100).round(2)
        
        return pd.DataFrame({
            'site': site_preference.index,
            'executions': site_counts.values,
            'preference_pct': site_preference.values
        }).sort_values('preference_pct', ascending=False)
    
    def calculate_agent_usage(self) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Calculate agent/champion usage by team and by player.
        
        Returns:
            Tuple of (team_usage_df, player_usage_df)
        """
        # Team-level usage
        team_usage = self.data.groupby('agent_or_champion').size()
        total_picks = team_usage.sum()
        team_usage_pct = (team_usage / total_picks * 100).round(2)
        
        team_df = pd.DataFrame({
            'agent_or_champion': team_usage_pct.index,
            'picks': team_usage.values,
            'usage_pct': team_usage_pct.values
        }).sort_values('usage_pct', ascending=False)
        
        # Player-level usage
        player_usage = self.data.groupby(['player', 'agent_or_champion']).size()
        player_df = player_usage.reset_index(name='picks')
        
        # Get top agent per player
        top_agents = player_df.loc[
            player_df.groupby('player')['picks'].idxmax()
        ].sort_values('picks', ascending=False)
        
        return team_df, top_agents
    
    def calculate_aggression_rate(self) -> Tuple[float, pd.DataFrame]:
        """
        Calculate team and player aggression rates based on first bloods.
        
        Returns:
            Tuple of (team_aggression_rate, player_aggression_df)
        """
        # Team aggression rate
        total_first_bloods = self.data['first_blood'].sum()
        team_aggression = (total_first_bloods / self.total_rounds * 100).round(2)
        
        # Player aggression rates
        player_stats = self.data.groupby('player').agg({
            'first_blood': 'sum',
            'rounds_played': 'sum'
        })
        
        player_stats['aggression_rate'] = (
            player_stats['first_blood'] / player_stats['rounds_played'] * 100
        ).round(2)
        
        player_stats['above_team_avg'] = (
            player_stats['aggression_rate'] > team_aggression
        )
        
        player_df = player_stats.reset_index().sort_values(
            'aggression_rate', ascending=False
        )
        
        return team_aggression, player_df
    
    def calculate_player_tendencies(self) -> pd.DataFrame:
        """
        Analyze player tendencies including role preference and engagement behavior.
        
        Returns:
            DataFrame with comprehensive player statistics
        """
        player_stats = self.data.groupby('player').agg({
            'role': lambda x: x.mode()[0] if not x.mode().empty else x.iloc[0],
            'rounds_played': 'sum',
            'rounds_won': 'sum',
            'first_blood': 'sum',
            'agent_or_champion': lambda x: x.mode()[0] if not x.mode().empty else x.iloc[0]
        }).reset_index()
        
        player_stats.columns = [
            'player', 'primary_role', 'total_rounds', 
            'rounds_won', 'first_bloods', 'favorite_agent'
        ]
        
        # Calculate win rate and aggression
        player_stats['win_rate'] = (
            player_stats['rounds_won'] / player_stats['total_rounds'] * 100
        ).round(2)
        
        player_stats['aggression_rate'] = (
            player_stats['first_bloods'] / player_stats['total_rounds'] * 100
        ).round(2)
        
        # Calculate first blood percentage (share of team's first bloods)
        total_fb = player_stats['first_bloods'].sum()
        if total_fb > 0:
            player_stats['first_blood_share'] = (
                player_stats['first_bloods'] / total_fb * 100
            ).round(2)
        else:
            player_stats['first_blood_share'] = 0.0
        
        return player_stats.sort_values('total_rounds', ascending=False)
    
    def identify_patterns(self) -> Dict[str, any]:
        """
        Identify strategic patterns and biases using threshold rules.
        
        Returns:
            Dictionary containing identified patterns and insights
        """
        patterns = {}
        
        # Map preferences (>40% threshold)
        map_pref = self.calculate_map_preference()
        preferred_maps = map_pref[map_pref['preference_pct'] > 40]
        patterns['preferred_maps'] = preferred_maps['map'].tolist()
        
        # Site bias (>60% threshold)
        site_pref = self.calculate_site_preference()
        biased_sites = site_pref[site_pref['preference_pct'] > 60]
        patterns['site_bias'] = biased_sites['site'].tolist()
        
        # Aggressive players (above team average)
        team_agg, player_agg = self.calculate_aggression_rate()
        aggressive_players = player_agg[
            player_agg['above_team_avg'] == True
        ]['player'].tolist()
        patterns['aggressive_players'] = aggressive_players
        patterns['team_aggression_rate'] = team_agg
        
        # Predictable agent picks (>30% usage)
        team_agents, _ = self.calculate_agent_usage()
        predictable_agents = team_agents[team_agents['usage_pct'] > 30]
        patterns['predictable_agents'] = predictable_agents['agent_or_champion'].tolist()
        
        # Win rate analysis
        total_rounds_won = self.data['rounds_won'].sum()
        team_win_rate = (total_rounds_won / self.total_rounds * 100).round(2)
        patterns['team_win_rate'] = team_win_rate
        
        return patterns
    
    def get_summary_statistics(self) -> Dict[str, any]:
        """
        Get high-level summary statistics for the scouting report.
        
        Returns:
            Dictionary with key metrics
        """
        return {
            'total_matches': self.total_matches,
            'total_rounds': int(self.total_rounds),
            'unique_players': self.data['player'].nunique(),
            'unique_maps': self.data['map'].nunique(),
            'unique_agents': self.data['agent_or_champion'].nunique()
        }
