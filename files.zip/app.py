"""
ScoutAI Streamlit Application
Interactive web interface for opponent scouting reports.
"""

import streamlit as st
import pandas as pd
from data_loader import MatchDataLoader
from analytics import ScoutingAnalytics
from report_generator import ScoutingReportGenerator
from visualizations import ScoutingVisualizer


# Page configuration
st.set_page_config(
    page_title="ScoutAI - Opponent Scouting",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded"
)


def load_custom_css():
    """Apply custom CSS styling."""
    st.markdown("""
    <style>
        .main-header {
            font-size: 2.5rem;
            font-weight: bold;
            color: #1f77b4;
            text-align: center;
            padding: 1rem;
        }
        .section-header {
            font-size: 1.5rem;
            font-weight: bold;
            color: #2c3e50;
            margin-top: 2rem;
            margin-bottom: 1rem;
            border-bottom: 2px solid #1f77b4;
            padding-bottom: 0.5rem;
        }
        .metric-box {
            background-color: #f0f2f6;
            padding: 1rem;
            border-radius: 0.5rem;
            border-left: 4px solid #1f77b4;
        }
        .stAlert {
            margin-top: 1rem;
        }
    </style>
    """, unsafe_allow_html=True)


def initialize_session_state():
    """Initialize session state variables."""
    if 'data_loaded' not in st.session_state:
        st.session_state.data_loaded = False
    if 'current_report' not in st.session_state:
        st.session_state.current_report = None


def main():
    """Main application function."""
    load_custom_css()
    initialize_session_state()
    
    # Header
    st.markdown('<p class="main-header">🎯 ScoutAI - Automated Opponent Scouting</p>', 
                unsafe_allow_html=True)
    st.markdown("---")
    
    # Sidebar configuration
    with st.sidebar:
        st.header("⚙️ Configuration")
        
        # File upload
        uploaded_file = st.file_uploader(
            "Upload Match Data CSV",
            type=['csv'],
            help="Upload a CSV file containing historical match data"
        )
        
        if uploaded_file is not None:
            try:
                # Save uploaded file temporarily
                with open("/tmp/match_data.csv", "wb") as f:
                    f.write(uploaded_file.getbuffer())
                
                # Load data
                loader = MatchDataLoader("/tmp/match_data.csv")
                st.session_state.data_loader = loader
                st.session_state.data_loaded = True
                st.success("✅ Data loaded successfully!")
                
                # Team selection
                st.subheader("Select Opponent")
                available_teams = loader.get_available_teams()
                selected_team = st.selectbox(
                    "Team to Scout",
                    available_teams,
                    help="Choose the opponent team to analyze"
                )
                
                # Match count selection
                st.subheader("Analysis Scope")
                match_count = st.slider(
                    "Number of Recent Matches",
                    min_value=1,
                    max_value=20,
                    value=5,
                    help="How many recent matches to analyze"
                )
                
                # Generate report button
                if st.button("🔍 Generate Scouting Report", type="primary"):
                    with st.spinner("Analyzing opponent data..."):
                        generate_report(
                            loader,
                            selected_team,
                            match_count
                        )
                
            except Exception as e:
                st.error(f"❌ Error loading data: {str(e)}")
                st.session_state.data_loaded = False
        
        else:
            st.info("👆 Upload a CSV file to begin")
            st.markdown("---")
            st.markdown("### Required CSV Columns:")
            st.code("""
- match_id
- date
- team
- opponent
- map
- site (or lane)
- player
- agent_or_champion
- role
- rounds_played
- rounds_won
- first_blood
            """)
    
    # Main content area
    if st.session_state.current_report:
        display_report(st.session_state.current_report)
    else:
        display_welcome_screen()


def generate_report(loader, team_name, num_matches):
    """
    Generate complete scouting report.
    
    Args:
        loader: MatchDataLoader instance
        team_name: Name of opponent team
        num_matches: Number of recent matches to analyze
    """
    try:
        # Get filtered data
        team_data = loader.get_opponent_data(team_name, num_matches)
        date_range = loader.get_date_range(team_data)
        
        # Perform analytics
        analytics = ScoutingAnalytics(team_data)
        
        # Collect all analytics data
        analytics_data = {
            'summary': analytics.get_summary_statistics(),
            'map_preference': analytics.calculate_map_preference(),
            'site_preference': analytics.calculate_site_preference(),
            'team_agents': analytics.calculate_agent_usage()[0],
            'player_agents': analytics.calculate_agent_usage()[1],
            'team_aggression': analytics.calculate_aggression_rate()[0],
            'player_aggression': analytics.calculate_aggression_rate()[1],
            'player_tendencies': analytics.calculate_player_tendencies(),
            'patterns': analytics.identify_patterns()
        }
        
        # Generate report
        report_gen = ScoutingReportGenerator(
            team_name,
            analytics_data,
            date_range
        )
        
        # Generate visualizations
        visualizer = ScoutingVisualizer(analytics_data, team_name)
        plots = visualizer.generate_all_plots()
        
        # Store in session state
        st.session_state.current_report = {
            'text': report_gen.generate_full_report(),
            'analytics': analytics_data,
            'plots': plots,
            'team_name': team_name,
            'date_range': date_range
        }
        
        st.success(f"✅ Report generated for {team_name}!")
        
    except Exception as e:
        st.error(f"❌ Error generating report: {str(e)}")


def display_report(report_data):
    """
    Display the generated scouting report.
    
    Args:
        report_data: Dictionary containing report components
    """
    # Summary metrics
    st.markdown('<p class="section-header">📊 Summary Metrics</p>', 
                unsafe_allow_html=True)
    
    summary = report_data['analytics']['summary']
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Matches Analyzed", summary['total_matches'])
    with col2:
        st.metric("Total Rounds", summary['total_rounds'])
    with col3:
        st.metric("Players Tracked", summary['unique_players'])
    with col4:
        win_rate = report_data['analytics']['patterns']['team_win_rate']
        st.metric("Team Win Rate", f"{win_rate}%")
    
    # Text report
    st.markdown('<p class="section-header">📝 Scouting Report</p>', 
                unsafe_allow_html=True)
    st.text_area(
        "Full Report",
        report_data['text'],
        height=400,
        label_visibility="collapsed"
    )
    
    # Visualizations
    st.markdown('<p class="section-header">📈 Visual Analysis</p>', 
                unsafe_allow_html=True)
    
    # Map preference
    col1, col2 = st.columns(2)
    with col1:
        st.pyplot(report_data['plots']['map_preference'])
    with col2:
        st.pyplot(report_data['plots']['site_preference'])
    
    # Agent usage
    st.pyplot(report_data['plots']['agent_usage'])
    
    # Player tendencies table
    st.markdown('<p class="section-header">👥 Player Tendencies</p>', 
                unsafe_allow_html=True)
    
    visualizer = ScoutingVisualizer(
        report_data['analytics'],
        report_data['team_name']
    )
    player_table = visualizer.create_player_tendency_table()
    
    st.dataframe(
        player_table,
        use_container_width=True,
        hide_index=True
    )
    
    # Download options
    st.markdown('<p class="section-header">💾 Export Options</p>', 
                unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    with col1:
        st.download_button(
            label="📄 Download Report (TXT)",
            data=report_data['text'],
            file_name=f"scout_report_{report_data['team_name']}.txt",
            mime="text/plain"
        )
    
    with col2:
        # Export player tendencies as CSV
        csv = player_table.to_csv(index=False)
        st.download_button(
            label="📊 Download Player Data (CSV)",
            data=csv,
            file_name=f"player_tendencies_{report_data['team_name']}.csv",
            mime="text/csv"
        )


def display_welcome_screen():
    """Display welcome screen when no report is loaded."""
    st.markdown("""
    ### Welcome to ScoutAI! 🎯
    
    **ScoutAI** is an automated opponent scouting system that analyzes historical 
    match data to provide actionable insights for esports teams.
    
    #### How to Use:
    1. **Upload** your match data CSV file using the sidebar
    2. **Select** the opponent team you want to scout
    3. **Choose** how many recent matches to analyze
    4. **Generate** your comprehensive scouting report
    
    #### What You'll Get:
    - 📊 Team playstyle analysis
    - 🗺️ Map and site preferences
    - 👥 Player tendencies and aggression metrics
    - 🎯 Exploitable weaknesses
    - 📈 Visual charts and statistics
    - 💾 Downloadable reports
    
    #### Supported Games:
    - Valorant
    - League of Legends
    - Any game with similar round-based or lane-based structure
    
    ---
    
    Get started by uploading your data in the sidebar! 👈
    """)


if __name__ == "__main__":
    main()
