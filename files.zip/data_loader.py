"""
ScoutAI Data Loader Module
Handles CSV ingestion, validation, and data filtering for opponent scouting.
"""

import pandas as pd
from typing import Optional


class MatchDataLoader:
    """Load and filter match data for scouting analysis."""
    
    def __init__(self, filepath: str):
        """
        Initialize the data loader with a CSV file.
        
        Args:
            filepath: Path to the CSV file containing match data
        """
        self.filepath = filepath
        self.data = None
        self._load_data()
    
    def _load_data(self) -> None:
        """Load CSV data and perform basic validation."""
        try:
            self.data = pd.read_csv(self.filepath)
            self._validate_columns()
            # Convert date to datetime
            self.data['date'] = pd.to_datetime(self.data['date'])
            # Ensure first_blood is boolean
            self.data['first_blood'] = self.data['first_blood'].astype(bool)
        except FileNotFoundError:
            raise FileNotFoundError(f"Data file not found: {self.filepath}")
        except Exception as e:
            raise ValueError(f"Error loading data: {str(e)}")
    
    def _validate_columns(self) -> None:
        """Validate that all required columns are present."""
        required_columns = [
            'match_id', 'date', 'team', 'opponent', 'map',
            'site', 'player', 'agent_or_champion', 'role',
            'rounds_played', 'rounds_won', 'first_blood'
        ]
        
        missing_columns = set(required_columns) - set(self.data.columns)
        if missing_columns:
            raise ValueError(f"Missing required columns: {missing_columns}")
    
    def get_opponent_data(
        self, 
        opponent_name: str, 
        num_matches: Optional[int] = 5
    ) -> pd.DataFrame:
        """
        Filter data for a specific opponent team.
        
        Args:
            opponent_name: Name of the opponent team to scout
            num_matches: Number of recent matches to analyze (None for all)
        
        Returns:
            Filtered DataFrame containing only opponent's matches
        """
        # Filter for opponent team
        opponent_data = self.data[self.data['team'] == opponent_name].copy()
        
        if opponent_data.empty:
            raise ValueError(f"No data found for team: {opponent_name}")
        
        # Sort by date descending and get most recent matches
        opponent_data = opponent_data.sort_values('date', ascending=False)
        
        if num_matches:
            # Get unique match IDs for the most recent N matches
            recent_match_ids = opponent_data['match_id'].unique()[:num_matches]
            opponent_data = opponent_data[
                opponent_data['match_id'].isin(recent_match_ids)
            ]
        
        return opponent_data
    
    def get_available_teams(self) -> list:
        """
        Get list of all teams in the dataset.
        
        Returns:
            Sorted list of team names
        """
        return sorted(self.data['team'].unique().tolist())
    
    def get_date_range(self, team_data: pd.DataFrame) -> tuple:
        """
        Get the date range for the filtered data.
        
        Args:
            team_data: Filtered DataFrame
        
        Returns:
            Tuple of (earliest_date, latest_date)
        """
        return (
            team_data['date'].min().strftime('%Y-%m-%d'),
            team_data['date'].max().strftime('%Y-%m-%d')
        )
