"""
ScoutAI Command Line Demo
Quick test script to demonstrate core functionality without the UI.
"""

from data_loader import MatchDataLoader
from analytics import ScoutingAnalytics
from report_generator import ScoutingReportGenerator
from visualizations import ScoutingVisualizer


def main():
    """Run a complete scouting analysis from the command line."""
    
    print("="*70)
    print("ScoutAI - Command Line Demo")
    print("="*70)
    print()
    
    # Load data
    print("📂 Loading match data...")
    loader = MatchDataLoader("sample_match_data.csv")
    available_teams = loader.get_available_teams()
    print(f"✅ Found {len(available_teams)} teams: {', '.join(available_teams)}")
    print()
    
    # Select opponent (default to first team)
    opponent_team = "Team Phoenix"
    num_matches = 5
    
    print(f"🎯 Analyzing opponent: {opponent_team}")
    print(f"📊 Matches to analyze: {num_matches}")
    print()
    
    # Get opponent data
    print("🔍 Filtering opponent data...")
    team_data = loader.get_opponent_data(opponent_team, num_matches)
    date_range = loader.get_date_range(team_data)
    print(f"✅ Data range: {date_range[0]} to {date_range[1]}")
    print()
    
    # Perform analytics
    print("🧮 Calculating metrics...")
    analytics = ScoutingAnalytics(team_data)
    
    # Collect all analytics
    analytics_data = {
        'summary': analytics.get_summary_statistics(),
        'map_preference': analytics.calculate_map_preference(),
        'site_preference': analytics.calculate_site_preference(),
        'team_agents': analytics.calculate_agent_usage()[0],
        'player_agents': analytics.calculate_agent_usage()[1],
        'team_aggression': analytics.calculate_aggression_rate()[0],
        'player_aggression': analytics.calculate_aggression_rate()[1],
        'player_tendencies': analytics.calculate_player_tendencies(),
        'patterns': analytics.identify_patterns()
    }
    print("✅ Analytics complete")
    print()
    
    # Generate report
    print("📝 Generating scouting report...")
    report_gen = ScoutingReportGenerator(
        opponent_team,
        analytics_data,
        date_range
    )
    
    full_report = report_gen.generate_full_report()
    print(full_report)
    
    # Generate visualizations
    print("\n📈 Generating visualizations...")
    visualizer = ScoutingVisualizer(analytics_data, opponent_team)
    
    # Save plots
    print("  • Creating map preference chart...")
    visualizer.plot_map_preference(save_path="map_preference.png")
    
    print("  • Creating agent usage chart...")
    visualizer.plot_agent_usage(save_path="agent_usage.png")
    
    print("  • Creating site preference chart...")
    visualizer.plot_site_preference(save_path="site_preference.png")
    
    visualizer.close_all()
    print("✅ Visualizations saved!")
    print()
    
    # Display some key statistics
    print("="*70)
    print("KEY STATISTICS")
    print("="*70)
    print()
    
    print("Top 3 Maps:")
    map_df = analytics_data['map_preference'].head(3)
    for _, row in map_df.iterrows():
        print(f"  • {row['map']}: {row['preference_pct']}%")
    print()
    
    print("Top 3 Agents:")
    agent_df = analytics_data['team_agents'].head(3)
    for _, row in agent_df.iterrows():
        print(f"  • {row['agent_or_champion']}: {row['usage_pct']}%")
    print()
    
    print("Top 3 Players (by rounds):")
    player_df = analytics_data['player_tendencies'].head(3)
    for _, row in player_df.iterrows():
        print(f"  • {row['player']}: {row['total_rounds']} rounds, {row['win_rate']}% WR")
    print()
    
    print("="*70)
    print("✅ Analysis complete! Check generated PNG files for charts.")
    print("="*70)


if __name__ == "__main__":
    main()
