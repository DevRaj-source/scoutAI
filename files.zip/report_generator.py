"""
ScoutAI Report Generator Module
Creates natural language scouting reports with actionable insights.
"""

from typing import Dict
import pandas as pd


class ScoutingReportGenerator:
    """Generate natural language scouting reports."""
    
    def __init__(
        self, 
        team_name: str,
        analytics_data: Dict,
        date_range: tuple
    ):
        """
        Initialize report generator.
        
        Args:
            team_name: Name of the opponent team
            analytics_data: Dictionary containing all analytics results
            date_range: Tuple of (start_date, end_date)
        """
        self.team_name = team_name
        self.data = analytics_data
        self.date_range = date_range
    
    def generate_header(self) -> str:
        """Generate report header with metadata."""
        summary = self.data['summary']
        
        header = f"""
{'='*70}
SCOUTAI OPPONENT SCOUTING REPORT
{'='*70}

Team: {self.team_name}
Analysis Period: {self.date_range[0]} to {self.date_range[1]}
Matches Analyzed: {summary['total_matches']}
Total Rounds: {summary['total_rounds']}
Players Tracked: {summary['unique_players']}

{'='*70}
"""
        return header
    
    def generate_playstyle_summary(self) -> str:
        """Generate team playstyle summary section."""
        patterns = self.data['patterns']
        team_agg = patterns['team_aggression_rate']
        win_rate = patterns['team_win_rate']
        
        # Determine playstyle descriptor
        if team_agg > 20:
            style = "highly aggressive"
        elif team_agg > 10:
            style = "moderately aggressive"
        else:
            style = "methodical and patient"
        
        # Performance descriptor
        if win_rate > 55:
            performance = "strong"
        elif win_rate > 45:
            performance = "balanced"
        else:
            performance = "struggling"
        
        summary = f"""
TEAM PLAYSTYLE OVERVIEW
{'-'*70}

{self.team_name} displays a {style} playstyle with a {win_rate}% round 
win rate, indicating {performance} recent performance.

"""
        return summary
    
    def generate_strategy_section(self) -> str:
        """Generate preferred strategies section."""
        patterns = self.data['patterns']
        map_pref = self.data['map_preference']
        site_pref = self.data['site_preference']
        
        strategy = f"""
PREFERRED STRATEGIES
{'-'*70}

Map Selection:
"""
        
        # Map preferences
        if patterns['preferred_maps']:
            for map_name in patterns['preferred_maps']:
                pct = map_pref[map_pref['map'] == map_name]['preference_pct'].iloc[0]
                strategy += f"  • Strong preference for {map_name} ({pct}% of matches)\n"
        else:
            strategy += f"  • No dominant map preference detected\n"
        
        strategy += "\nSite/Lane Execution:\n"
        
        # Site bias
        if patterns['site_bias']:
            for site in patterns['site_bias']:
                pct = site_pref[site_pref['site'] == site]['preference_pct'].iloc[0]
                strategy += f"  • Heavy bias toward {site} ({pct}% of executions)\n"
        else:
            # Show top 2 sites
            top_sites = site_pref.head(2)
            for _, row in top_sites.iterrows():
                strategy += f"  • {row['site']}: {row['preference_pct']}% of executions\n"
        
        strategy += "\nAgent/Champion Pool:\n"
        
        # Predictable picks
        team_agents = self.data['team_agents']
        top_agents = team_agents.head(3)
        for _, row in top_agents.iterrows():
            strategy += f"  • {row['agent_or_champion']}: {row['usage_pct']}% usage "
            if row['agent_or_champion'] in patterns['predictable_agents']:
                strategy += "(PREDICTABLE PATTERN)"
            strategy += "\n"
        
        strategy += "\n"
        return strategy
    
    def generate_player_section(self) -> str:
        """Generate key player tendencies section."""
        player_tendencies = self.data['player_tendencies']
        patterns = self.data['patterns']
        
        section = f"""
KEY PLAYER TENDENCIES
{'-'*70}

"""
        
        # Top 3 most active players
        top_players = player_tendencies.head(3)
        
        for idx, player in top_players.iterrows():
            section += f"{player['player']} ({player['primary_role']}):\n"
            section += f"  • Favorite Agent: {player['favorite_agent']}\n"
            section += f"  • Rounds Played: {player['total_rounds']}\n"
            section += f"  • Win Rate: {player['win_rate']}%\n"
            section += f"  • Aggression Rate: {player['aggression_rate']}%\n"
            
            # Check if aggressive
            if player['player'] in patterns['aggressive_players']:
                section += f"  • ⚠️  AGGRESSIVE PLAYER - Seeks early engagements "
                section += f"({player['first_blood_share']}% of team's first bloods)\n"
            
            section += "\n"
        
        return section
    
    def generate_weaknesses_section(self) -> str:
        """Generate exploitable weaknesses section."""
        patterns = self.data['patterns']
        site_pref = self.data['site_preference']
        
        section = f"""
EXPLOITABLE WEAKNESSES
{'-'*70}

"""
        
        weaknesses_found = False
        
        # Site predictability
        if patterns['site_bias']:
            weaknesses_found = True
            section += "Strategic Predictability:\n"
            for site in patterns['site_bias']:
                pct = site_pref[site_pref['site'] == site]['preference_pct'].iloc[0]
                section += f"  • Over-reliance on {site} ({pct}%) makes rotations predictable\n"
            section += "\n"
        
        # Agent pool limitations
        team_agents = self.data['team_agents']
        if len(team_agents) < 8:
            weaknesses_found = True
            section += "Limited Agent Pool:\n"
            section += f"  • Only {len(team_agents)} unique agents used - target bans effective\n"
            section += "\n"
        
        # Aggressive player counters
        if patterns['aggressive_players']:
            weaknesses_found = True
            section += "Aggression Counters:\n"
            for player in patterns['aggressive_players']:
                section += f"  • {player} consistently takes early duels - set crossfire traps\n"
            section += "\n"
        
        # Win rate weaknesses
        if patterns['team_win_rate'] < 50:
            weaknesses_found = True
            section += "Performance Issues:\n"
            section += f"  • Below 50% win rate ({patterns['team_win_rate']}%) indicates exploitable gaps\n"
            section += "\n"
        
        if not weaknesses_found:
            section += "  • Team shows well-rounded gameplay with no obvious exploits\n"
            section += "  • Focus on fundamentals and out-executing their strategies\n\n"
        
        return section
    
    def generate_full_report(self) -> str:
        """
        Generate complete scouting report.
        
        Returns:
            Formatted multi-section scouting report
        """
        report = self.generate_header()
        report += self.generate_playstyle_summary()
        report += self.generate_strategy_section()
        report += self.generate_player_section()
        report += self.generate_weaknesses_section()
        report += "="*70 + "\n"
        report += "END OF REPORT\n"
        report += "="*70 + "\n"
        
        return report
