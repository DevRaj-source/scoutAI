"""
ScoutAI Visualizations Module
Generate charts and tables for scouting reports.
"""

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd
from typing import Dict, List
import io


# Set style
sns.set_style("whitegrid")
plt.rcParams['figure.figsize'] = (10, 6)
plt.rcParams['font.size'] = 10


class ScoutingVisualizer:
    """Create visualizations for scouting data."""
    
    def __init__(self, analytics_data: Dict, team_name: str):
        """
        Initialize visualizer with analytics data.
        
        Args:
            analytics_data: Dictionary containing all analytics results
            team_name: Name of the opponent team
        """
        self.data = analytics_data
        self.team_name = team_name
    
    def plot_map_preference(self, save_path: str = None) -> plt.Figure:
        """
        Create bar chart for map preferences.
        
        Args:
            save_path: Optional path to save the figure
        
        Returns:
            Matplotlib figure object
        """
        map_data = self.data['map_preference']
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        bars = ax.bar(
            map_data['map'], 
            map_data['preference_pct'],
            color='steelblue',
            edgecolor='black',
            linewidth=1.2
        )
        
        # Highlight preferred maps (>40%)
        for i, (idx, row) in enumerate(map_data.iterrows()):
            if row['preference_pct'] > 40:
                bars[i].set_color('coral')
        
        ax.set_xlabel('Map', fontsize=12, fontweight='bold')
        ax.set_ylabel('Usage (%)', fontsize=12, fontweight='bold')
        ax.set_title(
            f'{self.team_name} - Map Preference Distribution',
            fontsize=14,
            fontweight='bold',
            pad=20
        )
        
        # Add value labels on bars
        for i, bar in enumerate(bars):
            height = bar.get_height()
            ax.text(
                bar.get_x() + bar.get_width()/2.,
                height,
                f'{height:.1f}%',
                ha='center',
                va='bottom',
                fontsize=10
            )
        
        # Add legend for colors
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='coral', edgecolor='black', label='Preferred (>40%)'),
            Patch(facecolor='steelblue', edgecolor='black', label='Normal usage')
        ]
        ax.legend(handles=legend_elements, loc='upper right')
        
        plt.xticks(rotation=45, ha='right')
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def plot_agent_usage(self, save_path: str = None, top_n: int = 10) -> plt.Figure:
        """
        Create bar chart for agent/champion usage.
        
        Args:
            save_path: Optional path to save the figure
            top_n: Number of top agents to display
        
        Returns:
            Matplotlib figure object
        """
        agent_data = self.data['team_agents'].head(top_n)
        
        fig, ax = plt.subplots(figsize=(10, 6))
        
        bars = ax.barh(
            agent_data['agent_or_champion'],
            agent_data['usage_pct'],
            color='mediumseagreen',
            edgecolor='black',
            linewidth=1.2
        )
        
        # Highlight predictable agents (>30%)
        patterns = self.data['patterns']
        for i, (idx, row) in enumerate(agent_data.iterrows()):
            if row['agent_or_champion'] in patterns['predictable_agents']:
                bars[i].set_color('orange')
        
        ax.set_xlabel('Usage (%)', fontsize=12, fontweight='bold')
        ax.set_ylabel('Agent/Champion', fontsize=12, fontweight='bold')
        ax.set_title(
            f'{self.team_name} - Top {top_n} Agent/Champion Usage',
            fontsize=14,
            fontweight='bold',
            pad=20
        )
        
        # Add value labels
        for i, bar in enumerate(bars):
            width = bar.get_width()
            ax.text(
                width,
                bar.get_y() + bar.get_height()/2.,
                f'{width:.1f}%',
                ha='left',
                va='center',
                fontsize=10,
                fontweight='bold'
            )
        
        # Invert y-axis so highest is on top
        ax.invert_yaxis()
        
        # Add legend
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='orange', edgecolor='black', label='Predictable (>30%)'),
            Patch(facecolor='mediumseagreen', edgecolor='black', label='Normal usage')
        ]
        ax.legend(handles=legend_elements, loc='lower right')
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def plot_site_preference(self, save_path: str = None) -> plt.Figure:
        """
        Create pie chart for site/lane preferences.
        
        Args:
            save_path: Optional path to save the figure
        
        Returns:
            Matplotlib figure object
        """
        site_data = self.data['site_preference']
        
        fig, ax = plt.subplots(figsize=(10, 8))
        
        # Create color palette
        colors = sns.color_palette("Set2", len(site_data))
        
        # Highlight biased sites
        patterns = self.data['patterns']
        explode = [0.1 if site in patterns['site_bias'] else 0 
                   for site in site_data['site']]
        
        wedges, texts, autotexts = ax.pie(
            site_data['preference_pct'],
            labels=site_data['site'],
            autopct='%1.1f%%',
            colors=colors,
            explode=explode,
            startangle=90,
            textprops={'fontsize': 11, 'fontweight': 'bold'}
        )
        
        # Enhance autopct text
        for autotext in autotexts:
            autotext.set_color('white')
        
        ax.set_title(
            f'{self.team_name} - Site/Lane Execution Distribution',
            fontsize=14,
            fontweight='bold',
            pad=20
        )
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path, dpi=300, bbox_inches='tight')
        
        return fig
    
    def create_player_tendency_table(self) -> pd.DataFrame:
        """
        Create formatted player tendencies table.
        
        Returns:
            Styled DataFrame for display
        """
        player_data = self.data['player_tendencies'].copy()
        patterns = self.data['patterns']
        
        # Select relevant columns
        display_cols = [
            'player', 'primary_role', 'favorite_agent',
            'total_rounds', 'win_rate', 'aggression_rate', 'first_blood_share'
        ]
        
        table_data = player_data[display_cols].copy()
        
        # Add aggression flag
        table_data['aggressive'] = table_data['player'].isin(
            patterns['aggressive_players']
        ).apply(lambda x: '⚠️' if x else '')
        
        # Rename columns for display
        table_data.columns = [
            'Player', 'Role', 'Fav Agent', 'Rounds',
            'Win %', 'Aggr %', 'FB %', 'Aggressive'
        ]
        
        return table_data
    
    def generate_all_plots(self, output_dir: str = None) -> Dict[str, plt.Figure]:
        """
        Generate all visualization plots.
        
        Args:
            output_dir: Optional directory to save all plots
        
        Returns:
            Dictionary mapping plot names to figure objects
        """
        plots = {}
        
        # Map preference
        save_path = f"{output_dir}/map_preference.png" if output_dir else None
        plots['map_preference'] = self.plot_map_preference(save_path)
        
        # Agent usage
        save_path = f"{output_dir}/agent_usage.png" if output_dir else None
        plots['agent_usage'] = self.plot_agent_usage(save_path)
        
        # Site preference
        save_path = f"{output_dir}/site_preference.png" if output_dir else None
        plots['site_preference'] = self.plot_site_preference(save_path)
        
        return plots
    
    def close_all(self):
        """Close all open matplotlib figures to free memory."""
        plt.close('all')
